#!/bin/bash

# apache upgrade, install, and enable,

sudo yum update
sudo yum -y install httpd
sudo systemctl start httpd
sudo systemctl enable httpd
sudo systemctl status httpd